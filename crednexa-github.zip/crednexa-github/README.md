# CredNexa — GitHub starter

A responsive static frontend inspired by the publicly visible CredNexa landing page. This is a recreated starter project, **not the original source code downloaded from Netlify**.

## Run locally
Open `index.html` in a browser. No build step or dependencies are required.

## Publish with GitHub Pages
1. Create a GitHub repository.
2. Upload `index.html`, `style.css`, `script.js`, and this README.
3. Open **Settings → Pages**.
4. Under Build and deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.

## Notes
- The calculator is an educational estimate only, not a credit decision or loan offer.
- Inputs are saved in the current browser using `localStorage`.
- This is a frontend-only demo; it does not include a backend, real AI integration, authentication, or lender APIs.
