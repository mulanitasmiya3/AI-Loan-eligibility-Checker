const form = document.getElementById('loanForm');
const fields = ['income', 'expenses', 'existing', 'rate', 'tenure'];
const money = n => new Intl.NumberFormat('en-IN', {style:'currency', currency:'INR', maximumFractionDigits:0}).format(Math.max(0, Math.round(n)));

function calculate() {
  const income = Math.max(0, Number(document.getElementById('income').value) || 0);
  const expenses = Math.max(0, Number(document.getElementById('expenses').value) || 0);
  const existing = Math.max(0, Number(document.getElementById('existing').value) || 0);
  const annualRate = Math.max(0.1, Number(document.getElementById('rate').value) || 12);
  const months = Number(document.getElementById('tenure').value) || 36;
  const surplus = Math.max(0, income - expenses - existing);
  const budget = Math.min(surplus, income * 0.35);
  const monthlyRate = annualRate / 1200;
  const factor = Math.pow(1 + monthlyRate, months);
  const principal = budget > 0 ? budget * (factor - 1) / (monthlyRate * factor) : 0;
  document.getElementById('capacity').textContent = money(surplus);
  document.getElementById('budget').textContent = money(budget);
  document.getElementById('loanAmount').textContent = money(principal);
  document.getElementById('tenureOut').textContent = `${months} months`;
  try {
    const values = {};
    fields.forEach(id => values[id] = document.getElementById(id).value);
    localStorage.setItem('crednexa-estimator', JSON.stringify(values));
  } catch (_) { /* Storage may be disabled; calculator still works. */ }
}
try {
  const saved = JSON.parse(localStorage.getItem('crednexa-estimator') || 'null');
  if (saved) fields.forEach(id => { if (saved[id] !== undefined) document.getElementById(id).value = saved[id]; });
} catch (_) {}
form.addEventListener('submit', event => { event.preventDefault(); calculate(); });
fields.forEach(id => document.getElementById(id).addEventListener('change', calculate));
document.getElementById('resetBtn').addEventListener('click', () => {
  try { localStorage.removeItem('crednexa-estimator'); } catch (_) {}
  document.getElementById('income').value = 60000;
  document.getElementById('expenses').value = 25000;
  document.getElementById('existing').value = 5000;
  document.getElementById('rate').value = 12;
  document.getElementById('tenure').value = 36;
  calculate();
});
document.getElementById('year').textContent = new Date().getFullYear();
calculate();
