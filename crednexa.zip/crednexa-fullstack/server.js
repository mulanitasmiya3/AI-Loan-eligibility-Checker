require("dotenv").config();

const path = require("path");
const fs = require("fs");
const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Database = require("better-sqlite3");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET;

if (!JWT_SECRET || JWT_SECRET.length < 32) {
  console.error("Set JWT_SECRET in .env to a random secret of at least 32 characters.");
  process.exit(1);
}

const dbPath = path.resolve(process.env.DB_FILE || "./data/crednexa.sqlite");
fs.mkdirSync(path.dirname(dbPath), { recursive: true });
const db = new Database(dbPath);
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
  CREATE TABLE IF NOT EXISTS estimates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    monthly_income REAL NOT NULL,
    monthly_expenses REAL NOT NULL,
    existing_emi REAL NOT NULL,
    annual_rate REAL NOT NULL,
    tenure_months INTEGER NOT NULL,
    monthly_capacity REAL NOT NULL,
    suggested_emi REAL NOT NULL,
    estimated_principal REAL NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
  );
`);

app.use(helmet());
app.use(express.json({ limit: "20kb" }));
app.use(express.static(path.join(__dirname, "public")));

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 30,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "Too many requests. Please try again later." }
});
app.use("/api/auth", authLimiter);

function validateNumber(value, name, min, max) {
  const n = Number(value);
  if (!Number.isFinite(n) || n < min || n > max) {
    throw new Error(`${name} must be between ${min} and ${max}.`);
  }
  return n;
}
function calculateEstimate(input) {
  const income = validateNumber(input.monthlyIncome, "Monthly income", 0, 100000000);
  const expenses = validateNumber(input.monthlyExpenses, "Monthly expenses", 0, 100000000);
  const existing = validateNumber(input.existingEmi, "Existing EMI", 0, 100000000);
  const rate = validateNumber(input.annualRate, "Annual interest rate", 0.1, 40);
  const tenure = validateNumber(input.tenureMonths, "Tenure", 12, 60);
  if (![12, 24, 36, 48, 60].includes(tenure)) throw new Error("Tenure must be 12, 24, 36, 48, or 60 months.");
  const capacity = Math.max(0, income - expenses - existing);
  const emiBudget = Math.min(capacity, income * 0.35);
  const r = rate / 1200;
  const factor = Math.pow(1 + r, tenure);
  const principal = emiBudget > 0 ? emiBudget * (factor - 1) / (r * factor) : 0;
  return {
    monthlyCapacity: round(capacity),
    suggestedEmi: round(emiBudget),
    estimatedPrincipal: round(principal),
    tenureMonths: tenure,
    annualRate: rate
  };
}
function round(n) { return Math.round(n * 100) / 100; }
function publicUser(user) { return { id: user.id, name: user.name, email: user.email }; }
function makeToken(user) {
  return jwt.sign({ sub: String(user.id), email: user.email }, JWT_SECRET, { expiresIn: "7d" });
}
function requireAuth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  if (!token) return res.status(401).json({ error: "Sign in to access this feature." });
  try {
    req.userId = Number(jwt.verify(token, JWT_SECRET).sub);
    next();
  } catch (_) {
    return res.status(401).json({ error: "Session expired or invalid. Please sign in again." });
  }
}

app.get("/api/health", (_req, res) => res.json({ status: "ok", service: "CredNexa API" }));

app.post("/api/auth/register", async (req, res) => {
  try {
    const name = String(req.body.name || "").trim();
    const email = String(req.body.email || "").trim().toLowerCase();
    const password = String(req.body.password || "");
    if (name.length < 2 || name.length > 80) return res.status(400).json({ error: "Name must be 2–80 characters." });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) return res.status(400).json({ error: "Enter a valid email address." });
    if (password.length < 8 || password.length > 128) return res.status(400).json({ error: "Password must be 8–128 characters." });
    const hash = await bcrypt.hash(password, 12);
    const result = db.prepare("INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)").run(name, email, hash);
    const user = db.prepare("SELECT id, name, email FROM users WHERE id = ?").get(result.lastInsertRowid);
    res.status(201).json({ user, token: makeToken(user) });
  } catch (err) {
    if (String(err.message).includes("UNIQUE")) return res.status(409).json({ error: "An account with this email already exists." });
    res.status(500).json({ error: "Could not create account." });
  }
});

app.post("/api/auth/login", async (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email);
  if (!user || !(await bcrypt.compare(password, user.password_hash))) {
    return res.status(401).json({ error: "Email or password is incorrect." });
  }
  res.json({ user: publicUser(user), token: makeToken(user) });
});

app.get("/api/me", requireAuth, (req, res) => {
  const user = db.prepare("SELECT id, name, email, created_at AS createdAt FROM users WHERE id = ?").get(req.userId);
  if (!user) return res.status(404).json({ error: "User not found." });
  res.json({ user });
});

app.post("/api/estimates", requireAuth, (req, res) => {
  try {
    const estimate = calculateEstimate(req.body || {});
    const input = {
      monthlyIncome: validateNumber(req.body.monthlyIncome, "Monthly income", 0, 100000000),
      monthlyExpenses: validateNumber(req.body.monthlyExpenses, "Monthly expenses", 0, 100000000),
      existingEmi: validateNumber(req.body.existingEmi, "Existing EMI", 0, 100000000)
    };
    const result = db.prepare(`
      INSERT INTO estimates
      (user_id, monthly_income, monthly_expenses, existing_emi, annual_rate, tenure_months, monthly_capacity, suggested_emi, estimated_principal)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(req.userId, input.monthlyIncome, input.monthlyExpenses, input.existingEmi,
      estimate.annualRate, estimate.tenureMonths, estimate.monthlyCapacity, estimate.suggestedEmi, estimate.estimatedPrincipal);
    res.status(201).json({ id: Number(result.lastInsertRowid), ...estimate });
  } catch (err) {
    res.status(400).json({ error: err.message || "Invalid estimate details." });
  }
});

app.get("/api/estimates", requireAuth, (req, res) => {
  const rows = db.prepare(`
    SELECT id, monthly_income AS monthlyIncome, monthly_expenses AS monthlyExpenses,
      existing_emi AS existingEmi, annual_rate AS annualRate, tenure_months AS tenureMonths,
      monthly_capacity AS monthlyCapacity, suggested_emi AS suggestedEmi,
      estimated_principal AS estimatedPrincipal, created_at AS createdAt
    FROM estimates WHERE user_id = ? ORDER BY id DESC LIMIT 100
  `).all(req.userId);
  res.json({ estimates: rows });
});

app.delete("/api/estimates/:id", requireAuth, (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: "Invalid estimate ID." });
  const result = db.prepare("DELETE FROM estimates WHERE id = ? AND user_id = ?").run(id, req.userId);
  if (!result.changes) return res.status(404).json({ error: "Estimate not found." });
  res.json({ success: true });
});

app.get("*", (req, res, next) => {
  if (req.path.startsWith("/api/")) return res.status(404).json({ error: "API route not found." });
  res.sendFile(path.join(__dirname, "public", "index.html"), err => { if (err) next(err); });
});

app.listen(PORT, () => console.log(`CredNexa running at http://localhost:${PORT}`));
