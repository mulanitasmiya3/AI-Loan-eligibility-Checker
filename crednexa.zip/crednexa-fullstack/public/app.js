const $ = id => document.getElementById(id);
const tokenKey = "crednexa-token";
const userKey = "crednexa-user";
let token = localStorage.getItem(tokenKey) || "";
let user = null;
try { user = JSON.parse(localStorage.getItem(userKey) || "null"); } catch (_) {}

const money = n => new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(Math.max(0, Math.round(n)));
let latest = null;
let authMode = "login";

async function api(path, options = {}) {
  const headers = { "Content-Type": "application/json", ...(options.headers || {}) };
  if (token) headers.Authorization = `Bearer ${token}`;
  const response = await fetch(`/api${path}`, { ...options, headers });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "Request failed.");
  return data;
}
function showToast(message) {
  $("toast").textContent = message;
  $("toast").classList.remove("hidden");
  setTimeout(() => $("toast").classList.add("hidden"), 2800);
}
function calculate() {
  const income = Math.max(0, Number($("income").value) || 0);
  const expenses = Math.max(0, Number($("expenses").value) || 0);
  const existingEmi = Math.max(0, Number($("existing").value) || 0);
  const annualRate = Math.min(40, Math.max(.1, Number($("rate").value) || 12));
  const tenureMonths = Number($("tenure").value) || 36;
  const monthlyCapacity = Math.max(0, income - expenses - existingEmi);
  const suggestedEmi = Math.min(monthlyCapacity, income * .35);
  const r = annualRate / 1200;
  const factor = Math.pow(1 + r, tenureMonths);
  const estimatedPrincipal = suggestedEmi > 0 ? suggestedEmi * (factor - 1) / (r * factor) : 0;
  latest = { monthlyIncome: income, monthlyExpenses: expenses, existingEmi, annualRate, tenureMonths, monthlyCapacity, suggestedEmi, estimatedPrincipal };
  $("capacity").textContent = money(monthlyCapacity);
  $("budget").textContent = money(suggestedEmi);
  $("loanAmount").textContent = money(estimatedPrincipal);
  $("tenureOut").textContent = `${tenureMonths} months`;
  $("saveEstimate").disabled = !token;
  $("saveEstimate").textContent = token ? "Save estimate to my account" : "Sign in to save estimate";
}
function setAuthUI() {
  $("authActions").innerHTML = user
    ? `<span class="muted">Hi, ${escapeHtml(user.name)}</span><button class="outline" id="accountBtn">My estimates</button><button class="outline" id="logoutTop">Sign out</button>`
    : `<button class="outline" id="loginOpen">Sign in</button><button class="primary small-btn" id="registerOpen">Create account</button>`;
  if (user) {
    $("accountBtn").addEventListener("click", loadHistory);
    $("logoutTop").addEventListener("click", logout);
  } else {
    $("loginOpen").addEventListener("click", () => openAuth("login"));
    $("registerOpen").addEventListener("click", () => openAuth("register"));
  }
  $("history").classList.toggle("hidden", !user);
  calculate();
}
function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
function openAuth(mode) {
  authMode = mode;
  $("authError").textContent = "";
  $("authModal").classList.remove("hidden");
  $("modalTitle").textContent = mode === "login" ? "Sign in" : "Create your account";
  $("authSubmit").textContent = mode === "login" ? "Sign in" : "Create account";
  $("nameWrap").classList.toggle("hidden", mode !== "register");
  $("name").required = mode === "register";
  $("switchAuth").innerHTML = mode === "login"
    ? 'New here? <button class="link-button" id="switchMode">Create an account</button>'
    : 'Already registered? <button class="link-button" id="switchMode">Sign in</button>';
  $("switchMode").addEventListener("click", () => openAuth(authMode === "login" ? "register" : "login"));
}
$("loginOpen").addEventListener("click", () => openAuth("login"));
$("registerOpen").addEventListener("click", () => openAuth("register"));
$("modalClose").addEventListener("click", () => $("authModal").classList.add("hidden"));
$("authModal").addEventListener("click", e => { if (e.target === $("authModal")) $("authModal").classList.add("hidden"); });
$("authForm").addEventListener("submit", async e => {
  e.preventDefault();
  $("authError").textContent = "";
  try {
    const body = { email: $("email").value.trim(), password: $("password").value };
    if (authMode === "register") body.name = $("name").value.trim();
    const result = await api(`/auth/${authMode === "login" ? "login" : "register"}`, { method: "POST", body: JSON.stringify(body) });
    token = result.token; user = result.user;
    localStorage.setItem(tokenKey, token); localStorage.setItem(userKey, JSON.stringify(user));
    $("authModal").classList.add("hidden");
    setAuthUI(); showToast(`Welcome${user.name ? ", " + user.name : ""}!`);
    await loadHistory();
  } catch (err) { $("authError").textContent = err.message; }
});
function logout() {
  token = ""; user = null;
  localStorage.removeItem(tokenKey); localStorage.removeItem(userKey);
  $("history").classList.add("hidden"); setAuthUI(); showToast("You have signed out.");
}
$("logoutBtn").addEventListener("click", logout);
$("loanForm").addEventListener("submit", e => { e.preventDefault(); calculate(); showToast("Estimate calculated."); });
["income", "expenses", "existing", "rate", "tenure"].forEach(id => $(id).addEventListener("input", calculate));
$("saveEstimate").addEventListener("click", async () => {
  if (!token) return openAuth("login");
  try {
    const result = await api("/estimates", { method: "POST", body: JSON.stringify(latest) });
    showToast("Estimate saved to your account.");
    await loadHistory();
  } catch (err) {
    if (err.message.toLowerCase().includes("sign in") || err.message.toLowerCase().includes("session")) logout();
    showToast(err.message);
  }
});
async function loadHistory() {
  if (!token) return openAuth("login");
  try {
    const result = await api("/estimates");
    $("history").classList.remove("hidden");
    $("historyList").innerHTML = result.estimates.length ? result.estimates.map(item => `
      <div class="history-item"><div><strong>${money(item.estimatedPrincipal)} estimated loan</strong>
      <p>${item.tenureMonths} months · ${item.annualRate}% annual rate · ${escapeHtml(item.createdAt)}</p></div>
      <button class="outline danger" data-delete="${item.id}">Delete</button></div>`).join("") : '<p class="muted">No saved estimates yet. Calculate and save one above.</p>';
    $("historyList").querySelectorAll("[data-delete]").forEach(btn => btn.addEventListener("click", async () => {
      try { await api(`/estimates/${btn.dataset.delete}`, { method: "DELETE" }); showToast("Estimate deleted."); await loadHistory(); }
      catch (err) { showToast(err.message); }
    }));
    $("history").scrollIntoView({ behavior: "smooth", block: "start" });
  } catch (err) { showToast(err.message); }
}
$("year").textContent = new Date().getFullYear();
calculate();
setAuthUI();
if (token && user) api("/me").catch(() => logout());
