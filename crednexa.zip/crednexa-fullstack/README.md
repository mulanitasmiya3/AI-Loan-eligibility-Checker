# CredNexa — Full-Stack Project

This is a full-stack starter inspired by the publicly visible CredNexa website. It is a recreated project, **not the original source code from the supplied Netlify URL**.

## Features

### Frontend
- Responsive CredNexa landing page
- Loan affordability calculator
- Registration and sign-in forms
- Saved-estimates dashboard
- Delete saved estimates
- Responsive styling for mobile and desktop

### Backend
- Node.js + Express REST API
- SQLite database (`users` and `estimates` tables)
- Password hashing with bcrypt
- JWT authentication
- Rate limiting on authentication endpoints
- Basic security headers with Helmet
- Input validation for calculator and account endpoints

### API routes
| Method | Route | Requires sign-in | Purpose |
|---|---|---:|---|
| GET | `/api/health` | No | API health check |
| POST | `/api/auth/register` | No | Create an account |
| POST | `/api/auth/login` | No | Sign in |
| GET | `/api/me` | Yes | Current account details |
| POST | `/api/estimates` | Yes | Calculate and save an estimate |
| GET | `/api/estimates` | Yes | List the signed-in user's estimates |
| DELETE | `/api/estimates/:id` | Yes | Delete one of your estimates |

## Requirements
- Node.js 20 or newer
- npm

## Run on your computer
1. Extract the ZIP.
2. Open a terminal inside the extracted `crednexa-fullstack` folder.
3. Install packages:
   ```bash
   npm install
   ```
4. Copy `.env.example` to `.env`.
5. Set `JWT_SECRET` in `.env` to a long random secret (at least 32 characters). Never commit `.env`.
6. Start the server:
   ```bash
   npm start
   ```
7. Visit `http://localhost:3000`.

The SQLite database is created automatically at `data/crednexa.sqlite` the first time the server starts.

## Push to GitHub
1. Create a new empty repository on GitHub.
2. Extract this ZIP.
3. Upload the contents of the `crednexa-fullstack` folder (not the ZIP itself) to the repository. Keep `.env` and `node_modules` out of Git.
4. Commit and push.

## Deployment
This app requires a **Node.js hosting service** for the backend; a static-only host such as GitHub Pages cannot run Express or SQLite. Deploy to a Node-compatible platform and configure `JWT_SECRET`, `PORT` (if required), and `DB_FILE` in the host's environment settings. Ensure persistent disk storage is configured for SQLite, or use a managed database for production.

For a production deployment, use HTTPS, a persistent database, secure token storage, account recovery, email verification, backups, monitoring, and a reviewed privacy policy. The current demo stores JWTs in browser local storage and is not intended for sensitive financial information.

## Important limitations
- This is a working educational demo, not a real lending service.
- It does not connect to banks, credit bureaus, lenders, or a real AI service.
- Calculator output is a simplified estimate, not financial advice or a loan approval.
- Do not enter banking passwords, card details, government ID numbers, or other sensitive information.
